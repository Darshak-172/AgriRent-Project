<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404 - Page Not Found</title>
    <link rel="stylesheet" href="../assets/css/error.css">
</head>
<body>
    <div class="container">
        <h2>🚧 Under Construction 🚧</h2>
        <p>We're working hard to bring you a better experience. Please check back soon!</p>
    </div>
</body>
</html>
