<div class="header">
    <div class="header-slider">
        <div class="slides">
            <div class="slide slide1"></div>
            <div class="slide slide2"></div>
            <div class="slide slide3"></div>
            <div class="slide slide4"></div>
            <div class="slide slide5"></div>
        </div>
    </div>
    <div class="header-overlay"></div>
    <div class="container" style="text-align: center;">
    <img src="Logo.png" alt="AgriRent Logo" style="height: 100px; width: 100px; background: rgba(255,255,255,0.95); border-radius: 50%; padding: 12px; margin-bottom: 20px; box-shadow: 0 6px 15px rgba(0,0,0,0.4); object-fit: cover; border: 3px solid #2d5016;">
    <h1>AgriRent - Farm Equipment Rental</h1>
    <p>Your trusted partner for agricultural equipment and supplies</p>
</div>


</div>
