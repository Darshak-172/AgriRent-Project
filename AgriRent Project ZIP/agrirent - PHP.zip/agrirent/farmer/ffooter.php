<div id="google_translate_element"></div>

<script type="text/javascript">
  function googleTranslateElementInit() {
    new google.translate.TranslateElement({
      pageLanguage: 'en', // Original site language
      includedLanguages: 'en,hi,gu', // Show options for Hindi & Gujarati
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, 'google_translate_element');
  }
</script>

<script type="text/javascript"
  src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit">
</script>
</body>
</html>
