<!DOCTYPE html>
<html>
<head>
    <title>Farmer Panel</title>
    <link rel="icon" type="image/png" href="favicon1.png" >
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
