<?php
session_start();
require_once('../auth/config.php');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'F') {
    header('Location: farmer_login.php');
    exit();
}

$user_id   = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

/*
 * STATUS (as per Data Dictionary)
 * equipment_bookings.status: PEN, CON, COM, REJ
 * product_orders.Status    : PEN, CON, COM, CAN
 * We treat 'COM' as completed/finished.
 */

/* -----------------------
   DATE FILTERS (From–To)
-------------------------*/
$today = new DateTime();
$date_from = $_GET['date_from'] ?? $today->format('Y-m-01');
$date_to   = $_GET['date_to']   ?? $today->format('Y-m-t');

// Validate date format (Y-m-d)
$df_obj = DateTime::createFromFormat('Y-m-d', $date_from);
$dt_obj = DateTime::createFromFormat('Y-m-d', $date_to);

if (!$df_obj) {
    $date_from = $today->format('Y-m-01');
}
if (!$dt_obj) {
    $date_to = $today->format('Y-m-t');
}

// Ensure from <= to
if (strtotime($date_from) > strtotime($date_to)) {
    $tmp       = $date_from;
    $date_from = $date_to;
    $date_to   = $tmp;
}

/* ------------------------------------
   EQUIPMENT RENTALS (Money Spent)
   status = 'COM' only
-------------------------------------*/
$bookings_query = "
    SELECT 
        eb.booking_id, e.Title, e.Brand, u.Name AS owner_name,
        eb.start_date, eb.end_date, eb.Hours, eb.total_amount, eb.status
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    JOIN users u ON e.Owner_id = u.user_id
    WHERE eb.customer_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
    ORDER BY eb.booking_id DESC
";
$stmt = $conn->prepare($bookings_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$bookings_data  = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$bookings_total = $bookings_data ? array_sum(array_map('floatval', array_column($bookings_data, 'total_amount'))) : 0;
$bookings_count = $bookings_data ? count($bookings_data) : 0;

/* ----------------------------------------
   PRODUCT PURCHASES (Money Spent, buyer)
   Status = 'COM'
-----------------------------------------*/
$orders_query = "
    SELECT 
        po.Order_id, p.Name AS product_name, u.Name AS seller_name,
        po.quantity, po.order_date, po.total_price, po.Status
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    JOIN users u ON p.seller_id = u.user_id
    WHERE po.buyer_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    ORDER BY po.Order_id DESC
";
$stmt = $conn->prepare($orders_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$orders_data  = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$orders_total = $orders_data ? array_sum(array_map('floatval', array_column($orders_data, 'total_price'))) : 0;
$orders_count = $orders_data ? count($orders_data) : 0;

/* --------------------------------------
   PRODUCT SALES (Money Earned, seller)
   Status = 'COM'
---------------------------------------*/
$sales_query = "
    SELECT 
        po.Order_id, p.Name AS product_name, u.Name AS buyer_name,
        po.quantity, po.order_date, po.total_price, po.Status
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    JOIN users u ON po.buyer_id = u.user_id
    WHERE p.seller_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    ORDER BY po.order_date DESC
";
$stmt = $conn->prepare($sales_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$sales_data  = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sales_total = $sales_data ? array_sum(array_map('floatval', array_column($sales_data, 'total_price'))) : 0;
$sales_count = $sales_data ? count($sales_data) : 0;

// Totals
$total_spent  = $bookings_total + $orders_total;
$total_earned = $sales_total;
$net_balance  = $total_earned - $total_spent;

/* ---------------------------------------
   MONTHLY TREND (Spent vs Earned)
----------------------------------------*/
// Rentals per month
$rent_month_query = "
    SELECT DATE_FORMAT(eb.start_date, '%Y-%m') AS ym,
           COALESCE(SUM(eb.total_amount), 0)    AS amount
    FROM equipment_bookings eb
    WHERE eb.customer_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
    GROUP BY ym
    ORDER BY ym
";
$stmt = $conn->prepare($rent_month_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$r_res = $stmt->get_result();
$rentMonthly = [];
while ($row = $r_res->fetch_assoc()) {
    $rentMonthly[$row['ym']] = (float)$row['amount'];
}
$stmt->close();

// Purchases per month
$buy_month_query = "
    SELECT DATE_FORMAT(po.order_date, '%Y-%m') AS ym,
           COALESCE(SUM(po.total_price), 0)     AS amount
    FROM product_orders po
    WHERE po.buyer_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    GROUP BY ym
    ORDER BY ym
";
$stmt = $conn->prepare($buy_month_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$b_res = $stmt->get_result();
$buyMonthly = [];
while ($row = $b_res->fetch_assoc()) {
    $buyMonthly[$row['ym']] = (float)$row['amount'];
}
$stmt->close();

// Sales per month
$sales_month_query = "
    SELECT DATE_FORMAT(po.order_date, '%Y-%m') AS ym,
           COALESCE(SUM(po.total_price), 0)     AS amount
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    WHERE p.seller_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    GROUP BY ym
    ORDER BY ym
";
$stmt = $conn->prepare($sales_month_query);
$stmt->bind_param("iss", $user_id, $date_from, $date_to);
$stmt->execute();
$s_res = $stmt->get_result();
$salesMonthly = [];
while ($row = $s_res->fetch_assoc()) {
    $salesMonthly[$row['ym']] = (float)$row['amount'];
}
$stmt->close();

// Merge months
$months_keys = array_unique(array_merge(
    array_keys($rentMonthly),
    array_keys($buyMonthly),
    array_keys($salesMonthly)
));
sort($months_keys);

$monthLabels     = [];
$rentMonthData   = [];
$buyMonthData    = [];
$salesMonthData  = [];

foreach ($months_keys as $ym) {
    $monthLabels[]    = date('M Y', strtotime($ym . '-01'));
    $rentMonthData[]  = $rentMonthly[$ym]  ?? 0;
    $buyMonthData[]   = $buyMonthly[$ym]   ?? 0;
    $salesMonthData[] = $salesMonthly[$ym] ?? 0;
}

/* ---------------------------------
   EXPORT HANDLER (PDF + EXCEL)
   (Same data, with logo + watermark)
----------------------------------*/
if (isset($_POST['export_format'])) {
    $format = $_POST['export_format'];

    ob_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Farmer Financial Report - AgriRent</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                font-size: 12px;
                color: #333;
                margin: 20px;
                position: relative;
            }
            .export-header {
                display: flex;
                align-items: center;
                border-bottom: 2px solid #234a23;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            .export-header img {
                height: 60px;
                width: 60px;
                border-radius: 50%;
                background: #fff;
                padding: 4px;
                object-fit: cover;
                box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                margin-right: 15px;
            }
            .export-header h1 {
                margin: 0;
                font-size: 20px;
                color: #234a23;
            }
            .export-header p {
                margin: 2px 0 0 0;
                font-size: 11px;
                color: #666;
            }
            h2 {
                margin-top: 25px;
                color: #234a23;
                font-size: 15px;
                border-bottom: 1px solid #e0e0e0;
                padding-bottom: 5px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
                margin-bottom: 15px;
            }
            th, td {
                border: 1px solid #999;
                padding: 6px 5px;
                text-align: left;
                font-size: 11px;
            }
            th {
                background: #e8f5e9;
                color: #234a23;
                font-weight: bold;
            }
            .amount-cell {
                text-align: right;
                font-weight: bold;
            }
            .summary-table th {
                width: 40%;
            }
            .watermark {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-30deg);
                font-size: 70px;
                color: rgba(35, 74, 35, 0.06);
                z-index: -1;
                pointer-events: none;
                white-space: nowrap;
            }
            .footer {
                margin-top: 20px;
                font-size: 10px;
                text-align: center;
                color: #777;
                border-top: 1px solid #e0e0e0;
                padding-top: 6px;
            }
            @media print {
                .watermark {
                    z-index: 0;
                }
            }
        </style>
    </head>
    <body>
        <div class="watermark">AgriRent</div>

        <div class="export-header">
            <img src="../Logo.png" alt="AgriRent Logo">
            <div>
                <h1>AgriRent - Farmer Financial Report</h1>
                <p>
                    Farmer: <strong><?= htmlspecialchars($user_name) ?></strong><br>
                    Period: <?= htmlspecialchars($date_from) ?> to <?= htmlspecialchars($date_to) ?><br>
                    Generated on: <?= date('d-m-Y H:i:s') ?>
                </p>
            </div>
        </div>

        <h2>Equipment Rentals (Money Spent)</h2>
        <table>
            <tr>
                <th>Booking ID</th>
                <th>Equipment</th>
                <th>Brand</th>
                <th>Owner</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Hours</th>
                <th>Amount (₹)</th>
            </tr>
            <?php if (!empty($bookings_data)): ?>
                <?php foreach ($bookings_data as $b): ?>
                    <tr>
                        <td><?= (int)$b['booking_id'] ?></td>
                        <td><?= htmlspecialchars($b['Title']) ?></td>
                        <td><?= htmlspecialchars($b['Brand'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($b['owner_name']) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['start_date'])) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['end_date'])) ?></td>
                        <td><?= (int)$b['Hours'] ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$b['total_amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="7" style="text-align:right;">TOTAL SPENT ON RENTALS</th>
                    <th class="amount-cell">₹<?= number_format($bookings_total, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="8" style="text-align:center;">No completed equipment rentals</td></tr>
            <?php endif; ?>
        </table>

        <h2>Product Purchases (Money Spent)</h2>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Seller</th>
                <th>Quantity</th>
                <th>Order Date</th>
                <th>Total (₹)</th>
            </tr>
            <?php if (!empty($orders_data)): ?>
                <?php foreach ($orders_data as $o): ?>
                    <tr>
                        <td><?= (int)$o['Order_id'] ?></td>
                        <td><?= htmlspecialchars($o['product_name']) ?></td>
                        <td><?= htmlspecialchars($o['seller_name']) ?></td>
                        <td><?= (float)$o['quantity'] ?></td>
                        <td><?= date('Y-m-d', strtotime($o['order_date'])) ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$o['total_price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="5" style="text-align:right;">TOTAL SPENT ON PURCHASES</th>
                    <th class="amount-cell">₹<?= number_format($orders_total, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;">No completed) product purchases</td></tr>
            <?php endif; ?>
        </table>

        <h2>Product Sales (Money Earned)</h2>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Buyer</th>
                <th>Quantity</th>
                <th>Sale Date</th>
                <th>Total (₹)</th>
            </tr>
            <?php if (!empty($sales_data)): ?>
                <?php foreach ($sales_data as $s): ?>
                    <tr>
                        <td><?= (int)$s['Order_id'] ?></td>
                        <td><?= htmlspecialchars($s['product_name']) ?></td>
                        <td><?= htmlspecialchars($s['buyer_name']) ?></td>
                        <td><?= (float)$s['quantity'] ?></td>
                        <td><?= date('Y-m-d', strtotime($s['order_date'])) ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$s['total_price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="5" style="text-align:right;">TOTAL EARNED FROM SALES</th>
                    <th class="amount-cell">₹<?= number_format($sales_total, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;">No completed) product sales</td></tr>
            <?php endif; ?>
        </table>

        <h2>Financial Summary</h2>
        <table class="summary-table">
            <tr>
                <th>Total Money Spent</th>
                <td class="amount-cell">₹<?= number_format($total_spent, 2) ?></td>
            </tr>
            <tr>
                <th>Total Money Earned</th>
                <td class="amount-cell">₹<?= number_format($total_earned, 2) ?></td>
            </tr>
            <tr>
                <th>Net Position (Earned - Spent)</th>
                <td class="amount-cell">₹<?= number_format($net_balance, 2) ?></td>
            </tr>
        </table>

        <div class="footer">
            This report was generated by AgriRent Farmer Dashboard. © <?= date('Y') ?> AgriRent. All rights reserved.
        </div>

        <?php if ($format === 'pdf'): ?>
        <script>
            window.onload = function() {
                window.print();
            };
        </script>
        <?php endif; ?>
    </body>
    </html>
    <?php
    $html = ob_get_clean();

    if ($format === 'excel') {
        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header("Content-Disposition: attachment; filename=Farmer_Report_".date('Ymd_His').".xls");
        echo $html;
        exit;
    }

    if ($format === 'pdf') {
        header("Content-Type: text/html; charset=utf-8");
        echo $html;
        exit;
    }
}

// AFTER export handling, load farmer header/nav
require 'fheader.php';
require 'farmer_nav.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Financial Report</title>
    <style>
        .main-content {
            margin-left: 250px; /* adjust to your sidebar width */
            padding: 25px;
            background-color: #f8f9fa;
            min-height: 100vh;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            background: white;
            padding: 20px 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .page-header h1 {
            color: #234a23;
            font-size: 26px;
            font-weight: 600;
            margin: 0;
        }

        .page-header p {
            margin: 5px 0 0 0;
            color: #666;
            font-size: 14px;
        }

        .export-buttons {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-primary {
            background: #234a23;
            color: white;
        }

        .btn-primary:hover {
            background: #1b371b;
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #28a745;
            color: white;
        }

        .btn-secondary:hover {
            background: #218838;
            transform: translateY(-1px);
        }

        .tabs {
            display: flex;
            gap: 1rem;
            margin: 15px 0 20px;
        }

        .tab {
            padding: 10px 20px;
            border-radius: 20px;
            background: #e9f2eb;
            color: #234a23;
            font-weight: 600;
            border: none;
            cursor: default;
        }

        /* Date Filter Card */
        .filter-card {
            background: white;
            padding: 18px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .filter-group label {
            font-size: 13px;
            color: #555;
            font-weight: 600;
        }

        .form-input {
            padding: 8px 10px;
            border-radius: 6px;
            border: 1px solid #ced4da;
            font-size: 14px;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .metric-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .metric-title {
            font-size: 14px;
            font-weight: 600;
            color: #6c757d;
        }

        .metric-total {
            font-size: 22px;
            font-weight: 700;
            color: #234a23;
        }

        .metric-sub {
            font-size: 13px;
            color: #777;
        }

        .activity-section {
            display: grid;
            grid-template-columns: 2fr 2fr;
            gap: 20px;
            margin-bottom: 25px;
        }

        .activity-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .activity-card h3 {
            margin: 0 0 15px 0;
            color: #234a23;
            font-size: 16px;
        }

        .status-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
        }

        .status-item {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
        }

        .status-label {
            font-size: 12px;
            color: #666;
        }

        .status-count {
            display: block;
            font-size: 18px;
            font-weight: 700;
            color: #234a23;
        }

        /* Charts */
        .charts-section {
            display: grid;
            grid-template-columns: 2fr 2fr 2fr;
            gap: 20px;
            margin-bottom: 25px;
        }

        .chart-card {
            background: white;
            padding: 18px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .chart-card h3 {
            margin: 0 0 10px 0;
            font-size: 15px;
            color: #234a23;
        }

        .full-width-chart {
            grid-column: 1 / -1;
        }

        .table-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .table-card h2 {
            margin: 0 0 15px 0;
            font-size: 16px;
            color: #234a23;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px 8px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }

        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }

        tr:hover td {
            background: #f8fbfa;
        }

        .amount {
            text-align: right;
            font-weight: 600;
            color: #234a23;
        }

        .total-row td {
            background: #234a23;
            color: white;
            font-weight: 700;
        }

        .no-data {
            text-align: center;
            padding: 25px 10px;
            color: #888;
            font-style: italic;
        }

        .summary-container {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-top: 10px;
        }

        .summary-title {
            font-size: 16px;
            font-weight: 600;
            color: #234a23;
            margin-bottom: 15px;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
        }

        .summary-card {
            background: #f8fbfa;
            border-radius: 8px;
            padding: 15px;
            border: 1px solid #e1e5ea;
        }

        .summary-card-label {
            font-size: 12px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            margin-bottom: 6px;
        }

        .summary-card-value {
            font-size: 20px;
            font-weight: 700;
            color: #234a23;
        }

        .summary-card-value.positive {
            color: #2e7d32;
        }

        .summary-card-value.negative {
            color: #c62828;
        }

        @media (max-width: 992px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .activity-section {
                grid-template-columns: 1fr;
            }
            .charts-section {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            .main-content {
                margin-left: 0;
                padding: 0;
            }
            .export-buttons, .filter-card {
                display: none !important;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Farmer Financial Report</h1>
            <p>
                Farmer: <strong><?php echo htmlspecialchars($user_name); ?></strong><br>
                Period: <?php echo htmlspecialchars($date_from); ?> to <?php echo htmlspecialchars($date_to); ?><br>
                Generated: <?php echo date('l, F j, Y H:i:s'); ?>
            </p>
        </div>
        <div class="export-buttons">
            <form method="POST" style="display:inline;">
                <button type="submit" name="export_format" value="pdf" class="btn btn-primary">Export PDF</button>
                <button type="submit" name="export_format" value="excel" class="btn btn-secondary">Export Excel</button>
            </form>
        </div>
    </div>

    <div class="tabs">
        <button class="tab">Report Overview</button>
    </div>

    <!-- DATE FILTERS -->
    <div class="filter-card">
        <form method="GET" class="filter-form">
            <div class="filter-group">
                <label>From Date:</label>
                <input type="date" name="date_from" class="form-input"
                       value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            <div class="filter-group">
                <label>To Date:</label>
                <input type="date" name="date_to" class="form-input"
                       value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary">Apply Filters</button>
            </div>
        </form>
    </div>

    <!-- Metrics like Admin -->
    <div class="metrics-grid">
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Total Money Spent</span>
                <span class="metric-total">₹<?php echo number_format($total_spent, 2); ?></span>
            </div>
            <div class="metric-sub">Rentals + Product Purchases</div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Total Money Earned</span>
                <span class="metric-total">₹<?php echo number_format($total_earned, 2); ?></span>
            </div>
            <div class="metric-sub">Income from Product Sales</div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Net Position</span>
                <span class="metric-total" style="color: <?php echo $net_balance >= 0 ? '#2e7d32' : '#c62828'; ?>">
                    ₹<?php echo number_format($net_balance, 2); ?>
                </span>
            </div>
            <div class="metric-sub">Earned - Spent</div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Transactions</span>
                <span class="metric-total"><?php echo $bookings_count + $orders_count + $sales_count; ?></span>
            </div>
            <div class="metric-sub">
                Rentals: <?php echo $bookings_count; ?> • Purchases: <?php echo $orders_count; ?> • Sales: <?php echo $sales_count; ?>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="charts-section">
        <div class="chart-card">
            <h3>Money Spent vs Earned (₹)</h3>
            <canvas id="spentEarnedChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>Breakdown of Money Spent</h3>
            <canvas id="spentBreakdownChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>Net Position (₹)</h3>
            <canvas id="netPositionChart"></canvas>
        </div>
        <div class="chart-card full-width-chart">
            <h3>Monthly Trend (Rentals, Purchases, Sales)</h3>
            <canvas id="monthlyTrendChart"></canvas>
        </div>
    </div>

    <!-- Activity-style section -->
    <div class="activity-section">
        <div class="activity-card">
            <h3>Spending Activity</h3>
            <div class="status-grid">
                <div class="status-item">
                    <span class="status-label">Equipment Rentals</span>
                    <span class="status-count"><?php echo $bookings_count; ?></span>
                </div>
                <div class="status-item">
                    <span class="status-label">Product Purchases</span>
                    <span class="status-count"><?php echo $orders_count; ?></span>
                </div>
                <div class="status-item">
                    <span class="status-label">Total Spent (₹)</span>
                    <span class="status-count"><?php echo number_format($total_spent, 0); ?></span>
                </div>
            </div>
        </div>
        <div class="activity-card">
            <h3>Earning Activity </h3>
            <div class="status-grid">
                <div class="status-item">
                    <span class="status-label">Sales Orders</span>
                    <span class="status-count"><?php echo $sales_count; ?></span>
                </div>
                <div class="status-item">
                    <span class="status-label">Total Earned (₹)</span>
                    <span class="status-count"><?php echo number_format($total_earned, 0); ?></span>
                </div>
                <div class="status-item">
                    <span class="status-label">Net Position (₹)</span>
                    <span class="status-count" style="color: <?php echo $net_balance >= 0 ? '#2e7d32' : '#c62828'; ?>">
                        <?php echo number_format($net_balance, 0); ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Tables -->
    <div class="table-card">
        <h2>Equipment Rentals (Money Spent, Completed)</h2>
        <?php if (!empty($bookings_data)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Equipment</th>
                        <th>Brand</th>
                        <th>Owner</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Hours</th>
                        <th>Amount (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings_data as $booking): ?>
                        <tr>
                            <td><strong><?php echo (int)$booking['booking_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($booking['Title']); ?></td>
                            <td><?php echo htmlspecialchars($booking['Brand'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($booking['owner_name']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($booking['start_date'])); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($booking['end_date'])); ?></td>
                            <td><?php echo (int)$booking['Hours']; ?></td>
                            <td class="amount">₹<?php echo number_format((float)$booking['total_amount'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="7" style="text-align:right;">TOTAL SPENT ON RENTALS</td>
                        <td class="amount">₹<?php echo number_format($bookings_total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed equipment rentals in this date range.</div>
        <?php endif; ?>
    </div>

    <div class="table-card">
        <h2>Product Purchases (Money Spent, Completed)</h2>
        <?php if (!empty($orders_data)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Seller</th>
                        <th>Quantity</th>
                        <th>Order Date</th>
                        <th>Total (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders_data as $order): ?>
                        <tr>
                            <td><strong><?php echo (int)$order['Order_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['seller_name']); ?></td>
                            <td><?php echo (float)$order['quantity']; ?></td>
                            <td><?php echo date('Y-m-d', strtotime($order['order_date'])); ?></td>
                            <td class="amount">₹<?php echo number_format((float)$order['total_price'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="5" style="text-align:right;">TOTAL SPENT ON PURCHASES</td>
                        <td class="amount">₹<?php echo number_format($orders_total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed product purchases in this date range.</div>
        <?php endif; ?>
    </div>

    <div class="table-card">
        <h2>Product Sales (Money Earned, Completed)</h2>
        <?php if (!empty($sales_data)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Buyer</th>
                        <th>Quantity</th>
                        <th>Sale Date</th>
                        <th>Total (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales_data as $sale): ?>
                        <tr>
                            <td><strong><?php echo (int)$sale['Order_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($sale['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($sale['buyer_name']); ?></td>
                            <td><?php echo (float)$sale['quantity']; ?></td>
                            <td><?php echo date('Y-m-d', strtotime($sale['order_date'])); ?></td>
                            <td class="amount">₹<?php echo number_format((float)$sale['total_price'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td colspan="5" style="text-align:right;">TOTAL EARNED FROM SALES</td>
                        <td class="amount">₹<?php echo number_format($sales_total, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed product sales in this date range.</div>
        <?php endif; ?>
    </div>

    <div class="summary-container">
        <div class="summary-title">Financial Summary</div>
        <div class="summary-grid">
            <div class="summary-card">
                <div class="summary-card-label">Total Money Spent</div>
                <div class="summary-card-value">₹<?php echo number_format($total_spent, 2); ?></div>
            </div>
            <div class="summary-card">
                <div class="summary-card-label">Total Money Earned</div>
                <div class="summary-card-value">₹<?php echo number_format($total_earned, 2); ?></div>
            </div>
            <div class="summary-card">
                <div class="summary-card-label">Net Position</div>
                <div class="summary-card-value <?php echo $net_balance >= 0 ? 'positive' : 'negative'; ?>">
                    ₹<?php echo number_format($net_balance, 2); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Agriculture colour palette
    const agrColors = {
        green:      '#2e7d32',
        lightGreen: '#66bb6a',
        yellow:     '#fbc02d',
        brown:      '#8d6e63',
        darkgreen:  '#234a23',
        red:        '#e53935',
        grey:       '#cfd8dc',
        darkgreen:  '#234a23'
    };

    const totalSpent      = <?php echo json_encode((float)$total_spent); ?>;
    const totalEarned     = <?php echo json_encode((float)$total_earned); ?>;
    const netBalance      = <?php echo json_encode((float)$net_balance); ?>;
    const rentalsTotal    = <?php echo json_encode((float)$bookings_total); ?>;
    const purchasesTotal  = <?php echo json_encode((float)$orders_total); ?>;

    const monthLabelsJs   = <?php echo json_encode($monthLabels); ?>;
    const rentMonthDataJs = <?php echo json_encode($rentMonthData); ?>;
    const buyMonthDataJs  = <?php echo json_encode($buyMonthData); ?>;
    const salesMonthDataJs= <?php echo json_encode($salesMonthData); ?>;

    // Money Spent vs Earned (Bar)
    const seCtx = document.getElementById('spentEarnedChart');
    if (seCtx) {
        new Chart(seCtx, {
            type: 'bar',
            data: {
                labels: ['Spent', 'Earned'],
                datasets: [{
                    label: 'Amount (₹)',
                    data: [totalSpent, totalEarned],
                    backgroundColor: [agrColors.darkgreen, agrColors.green],
                    borderColor: [agrColors.darkgreen, agrColors.green],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Breakdown of Spending (Rentals vs Purchases)
    const sbCtx = document.getElementById('spentBreakdownChart');
    if (sbCtx) {
        new Chart(sbCtx, {
            type: 'pie',
            data: {
                labels: ['Equipment Rentals', 'Product Purchases'],
                datasets: [{
                    data: [rentalsTotal, purchasesTotal],
                    backgroundColor: [agrColors.darkgreen, agrColors.yellow],
                    borderColor: '#ffffff',
                    borderWidth: 2
                }]
            },
            options: {
                plugins: { legend: { position: 'bottom' } },
                responsive: true
            }
        });
    }

    // Net Position
    const npCtx = document.getElementById('netPositionChart');
    if (npCtx) {
        const isPositive = netBalance >= 0;
        new Chart(npCtx, {
            type: 'bar',
            data: {
                labels: ['Net'],
                datasets: [{
                    label: 'Earned - Spent (₹)',
                    data: [netBalance],
                    backgroundColor: [isPositive ? agrColors.green : agrColors.red],
                    borderColor: [isPositive ? agrColors.green : agrColors.red],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Monthly Trend Line (Rentals, Purchases, Sales)
    const mtCtx = document.getElementById('monthlyTrendChart');
    if (mtCtx) {
        new Chart(mtCtx, {
            type: 'line',
            data: {
                labels: monthLabelsJs,
                datasets: [
                    {
                        label: 'Rentals Spent (₹)',
                        data: rentMonthDataJs,
                        borderColor: agrColors.darkgreen,
                        backgroundColor: 'rgba(141, 110, 99, 0.15)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Purchases Spent (₹)',
                        data: buyMonthDataJs,
                        borderColor: agrColors.yellow,
                        backgroundColor: 'rgba(251, 192, 45, 0.15)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Sales Earned (₹)',
                        data: salesMonthDataJs,
                        borderColor: agrColors.green,
                        backgroundColor: 'rgba(46, 125, 50, 0.15)',
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                plugins: { legend: { position: 'bottom' } },
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }
</script>
</body>
</html>

<?php require 'ffooter.php'; ?>
