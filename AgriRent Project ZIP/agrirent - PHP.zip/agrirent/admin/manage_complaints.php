<?php
session_start();
require_once('../auth/config.php');

/* ---------------------------------
   ACCESS CONTROL
---------------------------------- */
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'A') {
    header('Location: ../login.php');
    exit();
}

$message = '';
$error   = '';

/* ---------------------------------
   HANDLE STATUS + REPLY UPDATE
   - Status in `status`
   - Admin reply in `reply` column (NOT in description)
---------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_complaint'])) {
    $complaint_id = isset($_POST['complaint_id']) ? (int)$_POST['complaint_id'] : 0;
    $new_status   = $_POST['status'] ?? '';
    $reply_text   = trim($_POST['reply'] ?? '');

    $valid_status = ['O', 'P', 'R'];

    if ($complaint_id <= 0 || !in_array($new_status, $valid_status, true)) {
        $error = 'Invalid complaint or status.';
    } else {
        // Fetch current reply to append
        $check_sql = "SELECT Reply FROM complaints WHERE Complaint_id = ? LIMIT 1";
        $check_stmt = $conn->prepare($check_sql);

        if ($check_stmt) {
            $check_stmt->bind_param('i', $complaint_id);
            $check_stmt->execute();
            $res = $check_stmt->get_result();
            $row = $res->fetch_assoc();
            $check_stmt->close();
        } else {
            $row = null;
        }

        if (!$row) {
            $error = 'Complaint not found.';
        } else {
            $old_reply = (string)($row['Reply'] ?? '');

            $final_reply = $old_reply;
            if ($reply_text !== '') {
                $block = "ADMIN REPLY (" . date('Y-m-d H:i') . "):\n" . $reply_text;
                if ($final_reply !== '') {
                    $final_reply .= "\n\n" . $block;
                } else {
                    $final_reply = $block;
                }
            }

            // Update status + reply (description unchanged)
            $upd_sql = "UPDATE complaints 
                        SET Status = ?, Reply = ?, updated_at = NOW()
                        WHERE Complaint_id = ?";
            $upd_stmt = $conn->prepare($upd_sql);

            if ($upd_stmt) {
                $upd_stmt->bind_param('ssi', $new_status, $final_reply, $complaint_id);
                if ($upd_stmt->execute()) {
                    $message = 'Complaint updated successfully.';
                } else {
                    $error = 'Error updating complaint. Please try again.';
                }
                $upd_stmt->close();
            } else {
                $error = 'Error preparing update statement.';
            }
        }
    }
}

/* ---------------------------------
   PAGINATION + FILTERS
---------------------------------- */
$page  = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) { $page = 1; }

$limit  = 15;
$offset = ($page - 1) * $limit;

$status_filter = $_GET['status'] ?? 'all';
$type_filter   = $_GET['type']   ?? 'all';

$allowed_status = ['all', 'O', 'P', 'R'];
if (!in_array($status_filter, $allowed_status, true)) {
    $status_filter = 'all';
}
$allowed_types = ['all', 'E', 'P'];
if (!in_array($type_filter, $allowed_types, true)) {
    $type_filter = 'all';
}

/* ---------------------------------
   BUILD WHERE CLAUSE FOR FILTERS
---------------------------------- */
$where_parts   = [];
$filter_params = [];
$filter_types  = '';

if ($status_filter !== 'all') {
    $where_parts[]   = "c.Status = ?";
    $filter_params[] = $status_filter;
    $filter_types   .= 's';
}
if ($type_filter !== 'all') {
    $where_parts[]   = "c.Complaint_type = ?";
    $filter_params[] = $type_filter;
    $filter_types   .= 's';
}
$where_clause = !empty($where_parts) ? 'WHERE ' . implode(' AND ', $where_parts) : '';

/* ---------------------------------
   MAIN QUERY: ALL COMPLAINTS + AGAINST OWNER
---------------------------------- */
$sql = "
    SELECT 
        c.Complaint_id       AS complaint_id,
        c.User_id            AS user_id,
        c.Complaint_type     AS complaint_type,
        c.ID                 AS id,
        c.Description        AS description,
        c.Status             AS status,
        c.Reply              AS reply,
        c.created_at         AS created_at,

        u.Name               AS filed_by,
        u.Phone              AS filed_by_phone,

        -- Target name (equipment/product)
        CASE 
            WHEN c.Complaint_type = 'E' THEN e.Title
            WHEN c.Complaint_type = 'P' THEN p.Name
            ELSE NULL
        END AS target_name,

        -- AGAINST: Equipment owner / Product seller (user_id)
        CASE 
            WHEN c.Complaint_type = 'E' THEN e.Owner_id
            WHEN c.Complaint_type = 'P' THEN p.seller_id
            ELSE NULL
        END AS against_id,

        -- AGAINST: Owner / Seller name
        CASE 
            WHEN c.Complaint_type = 'E' THEN eo.Name
            WHEN c.Complaint_type = 'P' THEN po.Name
            ELSE NULL
        END AS against_name

    FROM complaints c
    JOIN users u 
        ON c.User_id = u.user_id

    LEFT JOIN equipment e
        ON c.Complaint_type = 'E'
       AND c.ID = e.Equipment_id
    LEFT JOIN users eo
        ON e.Owner_id = eo.user_id

    LEFT JOIN product p
        ON c.Complaint_type = 'P'
       AND c.ID = p.product_id
    LEFT JOIN users po
        ON p.seller_id = po.user_id

    $where_clause
    ORDER BY c.Complaint_id DESC
    LIMIT ? OFFSET ?
";

$params      = $filter_params;
$param_types = $filter_types . 'ii';
$params[]    = $limit;
$params[]    = $offset;

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Prepare error: ' . $conn->error);
}
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$complaints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/* ---------------------------------
   TOTAL COUNT (for pagination)
---------------------------------- */
$count_sql    = "SELECT COUNT(*) AS total FROM complaints c $where_clause";
$count_params = $filter_params;
$count_types  = $filter_types;

$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($count_params)) {
        $count_stmt->bind_param($count_types, ...$count_params);
    }
    $count_stmt->execute();
    $total_row        = $count_stmt->get_result()->fetch_assoc();
    $total_complaints = (int)($total_row['total'] ?? 0);
    $count_stmt->close();
} else {
    $total_complaints = 0;
}

$total_pages = ($total_complaints > 0) ? ceil($total_complaints / $limit) : 1;

/* ---------------------------------
   STATISTICS (overall)
---------------------------------- */
$stats_sql = "
    SELECT 
        COUNT(*) AS total,
        SUM(CASE WHEN Status = 'O' THEN 1 ELSE 0 END) AS open_count,
        SUM(CASE WHEN Status = 'P' THEN 1 ELSE 0 END) AS progress_count,
        SUM(CASE WHEN Status = 'R' THEN 1 ELSE 0 END) AS resolved_count
    FROM complaints
";

$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
$stats_stmt->close();

require 'header.php';
require 'admin_nav.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Complaints Management - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        .main-content {
            padding: 30px 20px;
            background: #f5f7fa;
            min-height: calc(100vh - 70px);
        }

        .page-header { margin-bottom: 20px; }
        .page-header h1 {
            color: #234a23;
            font-size: 32px;
            margin-bottom: 5px;
            font-weight: 600;
        }
        .page-header p {
            color: #666;
            font-size: 14px;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
            border-top: 4px solid #234a23;
        }
        .stat-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .stat-card .count {
            font-size: 34px;
            font-weight: bold;
            color: #234a23;
        }

        /* Filters */
        .filter-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-group {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .filter-group label {
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: #fff;
            cursor: pointer;
            font-size: 14px;
        }
        .filter-group select:hover { border-color: #234a23; }
        .complaint-count {
            margin-left: auto;
            color: #666;
            font-size: 14px;
        }

        /* Table */
        .complaints-table {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        table thead {
            background: #234a23;
            color: #fff;
        }
        table th {
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }
        table tbody tr {
            border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }
        table tbody tr:hover { background: #f9f9f9; }
        table tbody td {
            padding: 12px 10px;
            font-size: 14px;
            color: #333;
            vertical-align: top;
        }

        .complaint-id {
            font-weight: 600;
            color: #234a23;
        }

        .complaint-type {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .type-equipment { background: #e3f2fd; color: #1976d2; }
        .type-product   { background: #f3e5f5; color: #7b1fa2; }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: #fff;
        }
        .status-o { background: #dc3545; }
        .status-p { background: #ffc107; color: #212529; }
        .status-r { background: #28a745; }

        .description-preview {
            max-width: 260px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #666;
        }

        .user-info {
            font-size: 13px;
            color: #666;
        }
        .user-info strong { color: #234a23; }

        .btn {
            padding: 6px 12px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-view {
            background: #234a23;
            color: #fff;
        }
        .btn-view:hover { background: #1b371b; }

        .action-buttons { display: flex; gap: 5px; }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border-radius: 4px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #234a23;
            font-size: 13px;
        }
        .pagination a:hover {
            background: #234a23;
            color: #fff;
        }
        .pagination a.active {
            background: #234a23;
            color: #fff;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: #fff;
            border-radius: 8px;
            color: #999;
        }
        .empty-state h3 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal.show { display: block; }
        .modal-content {
            background: #fff;
            margin: 5% auto;
            padding: 24px;
            border-radius: 8px;
            max-width: 640px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .modal-header h2 {
            color: #234a23;
            font-size: 20px;
        }
        .modal-close {
            font-size: 26px;
            font-weight: bold;
            color: #999;
            cursor: pointer;
            border: none;
            background: none;
            width: 30px; height: 30px;
        }
        .modal-close:hover { color: #333; }

        .detail-row {
            margin-bottom: 8px;
            font-size: 14px;
        }
        .detail-row strong { color: #333; }

        #modalDescription {
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 6px;
            font-size: 14px;
            white-space: pre-wrap;
            color: #333;
        }

        #modalReplyView {
            margin-top: 12px;
            padding: 10px;
            background: #fff3cd;
            border-radius: 6px;
            border: 1px solid #ffeeba;
            font-size: 14px;
            white-space: pre-wrap;
            color: #856404;
        }

        .form-group {
            margin-top: 14px;
            margin-bottom: 10px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            font-size: 13px;
            color: #333;
        }
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 13px;
            font-family: inherit;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #234a23;
            box-shadow: 0 0 4px rgba(35,74,35,0.25);
        }
        .reply-actions {
            text-align: right;
            margin-top: 10px;
        }
        .btn-submit {
            background: #234a23;
            color: #fff;
        }
        .btn-submit:hover { background: #1b371b; }

        @media (max-width: 768px) {
            .filter-section { flex-direction: column; }
            .complaint-count { margin-left: 0; }
            table th, table td { padding: 10px 6px; }
            .description-preview { max-width: 160px; }
            .modal-content { margin: 15% auto; width: 92%; }
        }
    </style>
</head>
<body>

<div class="main-content">
    <div class="page-header">
        <h1>Complaints Management</h1>
        <p>View and manage all equipment and product complaints</p>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-container">
        <div class="stat-card">
            <h3>Total Complaints</h3>
            <div class="count"><?= (int)($stats['total'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>Open</h3>
            <div class="count"><?= (int)($stats['open_count'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>In Progress</h3>
            <div class="count"><?= (int)($stats['progress_count'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>Resolved</h3>
            <div class="count"><?= (int)($stats['resolved_count'] ?? 0) ?></div>
        </div>
    </div>

    <!-- Filters -->
    <div class="filter-section">
        <form method="GET" style="display:flex;gap:20px;flex-wrap:wrap;align-items:center;width:100%;">
            <div class="filter-group">
                <label>Type:</label>
                <select name="type" onchange="this.form.submit()">
                    <option value="all" <?= $type_filter === 'all' ? 'selected' : '' ?>>All Types</option>
                    <option value="E"   <?= $type_filter === 'E'   ? 'selected' : '' ?>>Equipment</option>
                    <option value="P"   <?= $type_filter === 'P'   ? 'selected' : '' ?>>Product</option>
                </select>
            </div>
            <div class="filter-group">
                <label>Status:</label>
                <select name="status" onchange="this.form.submit()">
                    <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All Status</option>
                    <option value="O"   <?= $status_filter === 'O'   ? 'selected' : '' ?>>Open</option>
                    <option value="P"   <?= $status_filter === 'P'   ? 'selected' : '' ?>>In Progress</option>
                    <option value="R"   <?= $status_filter === 'R'   ? 'selected' : '' ?>>Resolved</option>
                </select>
            </div>
            <span class="complaint-count">
                <?= count($complaints) ?> of <?= $total_complaints ?> complaint(s)
            </span>
        </form>
    </div>

    <!-- Complaints Table -->
    <?php if (!empty($complaints)): ?>
        <div class="complaints-table">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Against</th>
                            <th>Filed By</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($complaints as $c): 
                        $ctype_text = ($c['complaint_type'] === 'E')
                            ? 'Equipment'
                            : (($c['complaint_type'] === 'P') ? 'Product' : 'System');

                        $complaint_json = htmlspecialchars(json_encode($c), ENT_QUOTES, 'UTF-8');
                    ?>
                        <tr>
                            <td class="complaint-id"><?= (int)$c['complaint_id'] ?></td>
                            <td>
                                <span class="complaint-type <?= $c['complaint_type'] === 'E' ? 'type-equipment' : 'type-product' ?>">
                                    <?= htmlspecialchars($ctype_text) ?>
                                </span><br>
                                <small>ID: <?= (int)$c['id'] ?></small><br>
                                <?php if (!empty($c['target_name'])): ?>
                                    <small><?= htmlspecialchars($c['target_name']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="user-info">
                                    <strong>User ID:</strong> <?= (int)($c['against_id'] ?? 0) ?><br>
                                    <strong>Name:</strong> <?= htmlspecialchars($c['against_name'] ?? 'N/A') ?>
                                </div>
                            </td>
                            <td>
                                <div class="user-info">
                                    <strong><?= htmlspecialchars($c['filed_by']) ?></strong><br>
                                    <small><?= htmlspecialchars($c['filed_by_phone'] ?? '') ?></small>
                                </div>
                            </td>
                            <td>
                                <?php
                                $desc  = (string)$c['description'];
                                $short = mb_substr($desc, 0, 60, 'UTF-8');
                                if (mb_strlen($desc, 'UTF-8') > 60) { $short .= '...'; }
                                ?>
                                <div class="description-preview" title="<?= htmlspecialchars($desc) ?>">
                                    <?= htmlspecialchars($short) ?>
                                </div>
                            </td>
                            <td>
                                <?php
                                $st = $c['status'];
                                $status_text = ($st === 'O') ? 'Open' :
                                               (($st === 'P') ? 'In Progress' : 'Resolved');
                                ?>
                                <span class="status-badge status-<?= strtolower($st) ?>">
                                    <?= $status_text ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars(date('M d, Y', strtotime($c['created_at']))) ?></td>
                            <td>
                                <button class="btn btn-view"
                                    onclick='openComplaintModal(<?= $complaint_json ?>)'>
                                    View & Reply
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?= $i ?>&status=<?= urlencode($status_filter) ?>&type=<?= urlencode($type_filter) ?>"
                       class="<?= $page === $i ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="empty-state">
            <h3>No Complaints Found</h3>
            <p>There are no complaints matching your filters.</p>
        </div>
    <?php endif; ?>
</div>

<!-- Modal -->
<div id="complaintModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Complaint Details</h2>
            <button class="modal-close" onclick="closeComplaintModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div id="modalDetail"></div>
            <div id="modalDescription"></div>
            <div id="modalReplyView" style="display:none;"></div>

            <form method="POST" class="reply-form">
                <input type="hidden" name="complaint_id" id="modalComplaintId" value="">
                <div class="form-group">
                    <label for="modalStatus">Status</label>
                    <select name="status" id="modalStatus" required>
                        <option value="O">Open</option>
                        <option value="P">In Progress</option>
                        <option value="R">Resolved</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="modalReply">Add New Reply (optional)</label>
                    <textarea name="reply" id="modalReply"
                              placeholder="Write your reply to this complaint..."></textarea>
                </div>
                <div class="reply-actions">
                    <button type="submit" name="update_complaint" class="btn btn-submit">
                        Save Status / Reply
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text)
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function openComplaintModal(c) {
    const statusMap = { 'O': 'Open', 'P': 'In Progress', 'R': 'Resolved' };
    const typeText  = (c.complaint_type === 'E') ? 'Equipment'
                     : (c.complaint_type === 'P') ? 'Product'
                     : 'System';

    const againstRole = (c.complaint_type === 'E') ? 'Equipment Owner'
                      : (c.complaint_type === 'P') ? 'Product Seller'
                      : 'N/A';

    const detailHtml = `
        <div class="detail-row"><strong>ID:</strong> ${c.complaint_id}</div>
        <div class="detail-row"><strong>Type:</strong> ${typeText}</div>
        <div class="detail-row"><strong>Against:</strong> ${againstRole}
            (User ID: ${c.against_id || 'N/A'}, 
            Name: ${escapeHtml(c.against_name || 'N/A')})
        </div>
        <div class="detail-row"><strong>Filed By:</strong> ${escapeHtml(c.filed_by || '')}
            ${c.filed_by_phone ? ' (' + escapeHtml(c.filed_by_phone) + ')' : ''}
        </div>
        <div class="detail-row"><strong>Status:</strong>
            <span class="status-badge status-${(c.status || 'O').toLowerCase()}">
                ${statusMap[c.status] || c.status}
            </span>
        </div>
        <div class="detail-row"><strong>Created At:</strong> ${c.created_at || ''}</div>
    `;

    document.getElementById('modalDetail').innerHTML      = detailHtml;
    document.getElementById('modalDescription').textContent = c.description || '';

    const replyView = document.getElementById('modalReplyView');
    if (c.reply && c.reply.trim() !== '') {
        replyView.style.display = 'block';
        replyView.innerHTML = '<strong>Existing Replies:</strong><br>' + escapeHtml(c.reply);
    } else {
        replyView.style.display = 'none';
        replyView.innerHTML = '';
    }

    document.getElementById('modalComplaintId').value = c.complaint_id;
    document.getElementById('modalStatus').value      = c.status || 'O';
    document.getElementById('modalReply').value       = '';

    document.getElementById('complaintModal').classList.add('show');
}

function closeComplaintModal() {
    document.getElementById('complaintModal').classList.remove('show');
}

// Close modal when clicking outside
window.onclick = function (event) {
    const modal = document.getElementById('complaintModal');
    if (event.target === modal) {
        closeComplaintModal();
    }
};

// Auto-hide alerts after 5 seconds
setTimeout(function () {
    document.querySelectorAll('.alert').forEach(function (el) {
        el.style.display = 'none';
    });
}, 5000);
</script>

</body>
</html>

<?php require 'footer.php'; ?>
