<?php
session_start();
require_once('../auth/config.php');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'O') {
    header('Location: ../login.php');
    exit();
}

$owner_id   = (int)$_SESSION['user_id'];
$owner_name = $_SESSION['user_name'] ?? 'Equipment Owner';

$alert_msg  = '';
$alert_type = ''; // success / error

/* -----------------------------
   HANDLE OWNER REPLY + STATUS UPDATE (POST)
------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_complaint'])) {
    $complaint_id = (int)($_POST['complaint_id'] ?? 0);
    $new_status   = $_POST['status'] ?? '';
    $reply_text   = trim($_POST['reply_text'] ?? '');

    $valid_status = ['O', 'P', 'R'];

    if ($complaint_id <= 0 || !in_array($new_status, $valid_status, true)) {
        $alert_msg  = 'Invalid complaint or status.';
        $alert_type = 'error';
    } elseif (mb_strlen($reply_text) > 1000) {
        $alert_msg  = 'Reply is too long. Maximum 1000 characters allowed.';
        $alert_type = 'error';
    } else {
        // Check that complaint belongs to this owner (equipment or product)
        // AND complaint is filed by someone else (c.User_id <> owner)
        $check_sql = "
            SELECT 
                c.Description,
                c.reply
            FROM complaints c
            LEFT JOIN equipment e 
                ON (c.Complaint_type = 'E' AND c.ID = e.Equipment_id)
            LEFT JOIN product p 
                ON (c.Complaint_type = 'P' AND c.ID = p.product_id)
            WHERE c.Complaint_id = ?
              AND (e.Owner_id = ? OR p.seller_id = ?)
              AND c.User_id <> ?
            LIMIT 1
        ";

        $check_stmt = $conn->prepare($check_sql);
        if ($check_stmt) {
            $check_stmt->bind_param('iiii', $complaint_id, $owner_id, $owner_id, $owner_id);
            $check_stmt->execute();
            $result = $check_stmt->get_result();
            $row    = $result->fetch_assoc();
            $check_stmt->close();
        } else {
            $row = null;
        }

        if (!$row) {
            $alert_msg  = 'You are not authorized to update this complaint.';
            $alert_type = 'error';
        } else {
            $old_reply  = (string)($row['reply'] ?? '');
            $final_reply = $old_reply;

            // If owner has written a reply, append it to reply column (with timestamp & name)
            if ($reply_text !== '') {
                $timestamp = date('Y-m-d H:i');
                $prefix    = $old_reply !== '' ? ($old_reply . "\n\n") : '';
                $final_reply = $prefix . "Owner ({$owner_name}, {$timestamp}):\n" . $reply_text;
            }

            $upd_sql = "UPDATE complaints 
                        SET Status = ?, reply = ?
                        WHERE Complaint_id = ?";
            $upd_stmt = $conn->prepare($upd_sql);
            if ($upd_stmt) {
                $upd_stmt->bind_param('ssi', $new_status, $final_reply, $complaint_id);

                if ($upd_stmt->execute()) {
                    $alert_msg  = 'Complaint updated successfully.';
                    $alert_type = 'success';
                } else {
                    $alert_msg  = 'Failed to update complaint. Please try again.';
                    $alert_type = 'error';
                }
                $upd_stmt->close();
            } else {
                $alert_msg  = 'Error while preparing update query.';
                $alert_type = 'error';
            }
        }
    }
}

/* -----------------------------
   INPUT VALIDATION (GET)
------------------------------ */

// Page – must be positive integer
$page  = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) { $page = 1; }

$limit  = 10;
$offset = ($page - 1) * $limit;

// Status filter – allow only O, P, R or 'all'
$allowed_status = ['all', 'O', 'P', 'R'];
$status_filter  = $_GET['status'] ?? 'all';
if (!in_array($status_filter, $allowed_status, true)) {
    $status_filter = 'all';
}

/* -----------------------------------------------------
   MAIN QUERY: Complaints RECEIVED by this owner
   - Only where c.User_id <> owner_id (complaints from others)
   - E => join equipment, filter e.Owner_id = owner
   - P => join product,  filter p.seller_id = owner
   - show complainant details + target name + reply
------------------------------------------------------ */

$statusCondition = ($status_filter !== 'all') ? " AND c.Status = ?" : "";

// Main data (with UNION for Equipment + Product)
$sql = "
    SELECT * FROM (
        -- Equipment Complaints
        SELECT 
            c.Complaint_id,
            c.Complaint_type,
            c.Description,
            c.reply,
            c.Status,
            c.created_at,
            'Equipment' AS target_type,
            e.Title      AS target_name,
            u.Name       AS complainant_name,
            u.Phone      AS complainant_phone
        FROM complaints c
        JOIN equipment e ON c.ID = e.Equipment_id
        JOIN users    u   ON c.User_id = u.user_id
        WHERE c.Complaint_type = 'E'
          AND e.Owner_id = ?
          AND c.User_id <> ?
          $statusCondition

        UNION ALL

        -- Product Complaints
        SELECT 
            c.Complaint_id,
            c.Complaint_type,
            c.Description,
            c.reply,
            c.Status,
            c.created_at,
            'Product' AS target_type,
            p.Name    AS target_name,
            u.Name    AS complainant_name,
            u.Phone   AS complainant_phone
        FROM complaints c
        JOIN product  p ON c.ID = p.product_id
        JOIN users    u ON c.User_id = u.user_id
        WHERE c.Complaint_type = 'P'
          AND p.seller_id = ?
          AND c.User_id <> ?
          $statusCondition
    ) AS t
    ORDER BY t.Complaint_id DESC
    LIMIT ? OFFSET ?
";

$param_types = "ii";               // e.Owner_id, c.User_id<>
$params      = [$owner_id, $owner_id];

if ($status_filter !== 'all') {
    $param_types .= "s";
    $params[] = $status_filter;
}

$param_types .= "ii";              // p.seller_id, c.User_id<>
$params[]      = $owner_id;
$params[]      = $owner_id;

if ($status_filter !== 'all') {
    $param_types .= "s";
    $params[] = $status_filter;
}

$param_types .= "ii";              // limit, offset
$params[]      = $limit;
$params[]      = $offset;

$stmt = $conn->prepare($sql);
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$complaints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/* ---------------------------------
   TOTAL COUNT FOR PAGINATION
---------------------------------- */

$count_sql = "
    SELECT COUNT(*) AS total FROM (
        SELECT c.Complaint_id
        FROM complaints c
        JOIN equipment e ON c.ID = e.Equipment_id
        WHERE c.Complaint_type = 'E'
          AND e.Owner_id = ?
          AND c.User_id <> ?
          $statusCondition

        UNION ALL

        SELECT c.Complaint_id
        FROM complaints c
        JOIN product p ON c.ID = p.product_id
        WHERE c.Complaint_type = 'P'
          AND p.seller_id = ?
          AND c.User_id <> ?
          $statusCondition
    ) AS t
";

$count_param_types = "ii";           // e.Owner_id, c.User_id<>
$count_params      = [$owner_id, $owner_id];

if ($status_filter !== 'all') {
    $count_param_types .= "s";
    $count_params[] = $status_filter;
}

$count_param_types .= "ii";          // p.seller_id, c.User_id<>
$count_params[]      = $owner_id;
$count_params[]      = $owner_id;

if ($status_filter !== 'all') {
    $count_param_types .= "s";
    $count_params[] = $status_filter;
}

$count_stmt = $conn->prepare($count_sql);
$count_stmt->bind_param($count_param_types, ...$count_params);
$count_stmt->execute();
$total_row         = $count_stmt->get_result()->fetch_assoc();
$total_complaints  = (int)($total_row['total'] ?? 0);
$count_stmt->close();

$total_pages = ($total_complaints > 0) ? ceil($total_complaints / $limit) : 1;

/* ---------------------------------
   STATS: total / open / progress / resolved
   (based ONLY on complaints received from others)
---------------------------------- */

$stats_sql = "
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN Status = 'O' THEN 1 ELSE 0 END) AS open_count,
        SUM(CASE WHEN Status = 'P' THEN 1 ELSE 0 END) AS progress_count,
        SUM(CASE WHEN Status = 'R' THEN 1 ELSE 0 END) AS resolved_count
    FROM (
        SELECT c.Status
        FROM complaints c
        JOIN equipment e ON c.ID = e.Equipment_id
        WHERE c.Complaint_type = 'E'
          AND e.Owner_id = ?
          AND c.User_id <> ?

        UNION ALL

        SELECT c.Status
        FROM complaints c
        JOIN product p ON c.ID = p.product_id
        WHERE c.Complaint_type = 'P'
          AND p.seller_id = ?
          AND c.User_id <> ?
    ) AS t
";

$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->bind_param("iiii", $owner_id, $owner_id, $owner_id, $owner_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
$stats_stmt->close();

require 'oheader.php';
require 'owner_nav.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Received Complaints - AgriRent</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        .main-content {
            padding: 30px 20px;
            background: #f5f7fa;
            min-height: calc(100vh - 70px);
            margin-left: 250px;
        }

        .page-header { margin-bottom: 20px; }

        .page-header h1 {
            color: #234a23;
            font-size: 32px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .page-header p {
            color: #666;
            font-size: 14px;
        }

        /* Alerts */
        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            border-top: 4px solid #234a23;
        }

        .stat-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .stat-card .count {
            font-size: 34px;
            font-weight: bold;
            color: #234a23;
        }

        /* Filter */
        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
        }

        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .filter-group label {
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: white;
            cursor: pointer;
            font-size: 14px;
        }

        .filter-group select:hover { border-color: #234a23; }

        .complaint-count {
            margin-left: auto;
            color: #666;
            font-size: 14px;
        }

        /* Table */
        .complaints-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: #234a23;
            color: white;
        }

        table th {
            padding: 12px 14px;
            text-align: left;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        table tbody tr {
            border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }

        table tbody tr:hover { background: #f9f9f9; }

        table tbody td {
            padding: 12px 14px;
            font-size: 14px;
            color: #333;
            vertical-align: top;
        }

        .complaint-id {
            font-weight: 600;
            color: #234a23;
        }

        .target-pill {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .target-equipment { background: #e3f2fd; color: #1565c0; }
        .target-product   { background: #f3e5f5; color: #7b1fa2; }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: white;
        }

        .status-o { background: #dc3545; }
        .status-p { background: #ffc107; color: #212529; }
        .status-r { background: #28a745; }

        .description-preview {
            max-width: 260px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #555;
        }

        .user-info {
            font-size: 13px;
            color: #555;
        }

        .user-info strong { color: #234a23; }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }

        .btn-view {
            background: #234a23;
            color: white;
        }
        .btn-view:hover { background: #1b371b; }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }

        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            color: #234a23;
            text-decoration: none;
            font-size: 13px;
        }

        .pagination a:hover {
            background: #234a23;
            color: white;
        }

        .pagination a.active {
            background: #234a23;
            color: white;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 8px;
            color: #999;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .empty-state h3 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal.show { display: block; }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 24px;
            border-radius: 8px;
            max-width: 640px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .modal-header h2 {
            color: #234a23;
            font-size: 20px;
            margin: 0;
        }

        .modal-close {
            font-size: 24px;
            font-weight: bold;
            color: #999;
            cursor: pointer;
            border: none;
            background: none;
            padding: 0;
            width: 30px; height: 30px;
        }

        .modal-close:hover { color: #333; }

        .detail-row {
            margin-bottom: 8px;
            font-size: 14px;
        }

        .detail-row strong { color: #333; }

        .modal-description {
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 6px;
            font-size: 14px;
            color: #333;
            white-space: pre-wrap;
        }

        .reply-section {
            margin-top: 18px;
            padding-top: 12px;
            border-top: 1px solid #eee;
        }

        .reply-section h3 {
            font-size: 16px;
            color: #234a23;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 10px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            font-size: 13px;
            color: #333;
        }

        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
            font-family: inherit;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #234a23;
            box-shadow: 0 0 4px rgba(35,74,35,0.25);
        }

        .reply-actions {
            margin-top: 10px;
            text-align: right;
        }

        .btn-submit-reply {
            background: #234a23;
            color: #fff;
        }
        .btn-submit-reply:hover { background: #1b371b; }

        @media (max-width: 900px) {
            .main-content { margin-left: 0; }
        }

        @media (max-width: 768px) {
            .stats-container { grid-template-columns: repeat(2, 1fr); }

            .filter-section {
                flex-direction: column;
                align-items: flex-start;
            }

            table th, table td { padding: 10px 8px; }

            .description-preview { max-width: 150px; }

            .modal-content {
                margin: 15% auto;
                width: 92%;
            }
        }
    </style>
</head>
<body>
<div class="main-content">
    <div class="page-header">
        <h1>Received Complaints</h1>
        <p>Complaints submitted by users about your equipment and products</p>
    </div>

    <?php if ($alert_msg !== ''): ?>
        <div class="alert <?= $alert_type === 'success' ? 'alert-success' : 'alert-error' ?>">
            <?= htmlspecialchars($alert_msg) ?>
        </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-container">
        <div class="stat-card">
            <h3>Total Complaints</h3>
            <div class="count"><?= (int)($stats['total'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>Open</h3>
            <div class="count"><?= (int)($stats['open_count'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>In Progress</h3>
            <div class="count"><?= (int)($stats['progress_count'] ?? 0) ?></div>
        </div>
        <div class="stat-card">
            <h3>Resolved</h3>
            <div class="count"><?= (int)($stats['resolved_count'] ?? 0) ?></div>
        </div>
    </div>

    <!-- Filter -->
    <div class="filter-section">
        <form method="GET">
            <div class="filter-group">
                <label for="status">Status:</label>
                <select name="status" id="status" onchange="this.form.submit()">
                    <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="O"   <?= $status_filter === 'O'   ? 'selected' : '' ?>>Open</option>
                    <option value="P"   <?= $status_filter === 'P'   ? 'selected' : '' ?>>In Progress</option>
                    <option value="R"   <?= $status_filter === 'R'   ? 'selected' : '' ?>>Resolved</option>
                </select>
            </div>
            <?php if ($total_complaints > 0): ?>
                <div class="complaint-count">
                    Showing <?= count($complaints) ?> of <?= $total_complaints ?> complaints
                </div>
            <?php endif; ?>
        </form>
    </div>

    <?php if (!empty($complaints)): ?>
        <div class="complaints-table">
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Against</th>
                    <th>Complainant</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($complaints as $c): ?>
                    <tr>
                        <td class="complaint-id">#<?= (int)$c['Complaint_id'] ?></td>
                        <td>
                            <span class="target-pill <?= strtolower($c['target_type']) === 'equipment' ? 'target-equipment' : 'target-product' ?>">
                                <?= htmlspecialchars($c['target_type']) ?>
                            </span><br>
                            <span><?= htmlspecialchars($c['target_name']) ?></span>
                        </td>
                        <td>
                            <div class="user-info">
                                <strong><?= htmlspecialchars($c['complainant_name']) ?></strong><br>
                                <?php if (!empty($c['complainant_phone'])): ?>
                                    <small><?= htmlspecialchars($c['complainant_phone']) ?></small>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php
                            $desc  = (string)$c['Description'];
                            $short = mb_substr($desc, 0, 60, 'UTF-8');
                            if (mb_strlen($desc, 'UTF-8') > 60) {
                                $short .= '...';
                            }
                            ?>
                            <div class="description-preview"
                                 title="<?= htmlspecialchars($desc) ?>">
                                <?= htmlspecialchars($short) ?>
                            </div>
                        </td>
                        <td>
                            <?php
                            $status      = $c['Status'];
                            $status_text = ($status === 'O') ? 'Open' :
                                           (($status === 'P') ? 'In Progress' : 'Resolved');
                            ?>
                            <span class="status-badge status-<?= strtolower($status) ?>">
                                <?= $status_text ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($c['created_at']))) ?></td>
                        <td>
                            <button class="btn btn-view"
                                    onclick='viewComplaint(<?= htmlspecialchars(json_encode($c), ENT_QUOTES, "UTF-8") ?>)'>
                                View / Reply
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?= $i ?>&status=<?= urlencode($status_filter) ?>"
                       class="<?= $page === $i ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="empty-state">
            <h3>No Complaints Received</h3>
            <p>
                <?= $status_filter !== 'all'
                    ? 'No complaints with the selected status for your equipment/products.'
                    : 'You have not received any complaints yet from other users.' ?>
            </p>
        </div>
    <?php endif; ?>
</div>

<!-- Modal -->
<div id="complaintModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Complaint Details</h2>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div id="modal-detail"></div>
            <div class="modal-description" id="modal-description"></div>

            <div id="replyContainer" style="display:none; margin-top:12px;">
                <strong>Previous Reply:</strong>
                <div class="modal-description" id="modal-reply" style="margin-top:6px;"></div>
            </div>

            <div class="reply-section">
                <h3>Owner Reply / Update Status</h3>
                <form method="POST" id="replyForm">
                    <input type="hidden" name="complaint_id" id="modalComplaintId" value="">
                    <div class="form-group">
                        <label for="modalStatusSelect">Status</label>
                        <select name="status" id="modalStatusSelect" required>
                            <option value="O">Open</option>
                            <option value="P">In Progress</option>
                            <option value="R">Resolved</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="replyText">Reply (optional)</label>
                        <textarea name="reply_text" id="replyText" maxlength="1000"
                                  placeholder="Write your reply for this complaint..."></textarea>
                    </div>
                    <div class="reply-actions">
                        <button type="submit" name="update_complaint" class="btn btn-submit-reply">
                            Save Status / Reply
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<script>
    function viewComplaint(c) {
        const statusMap = { 'O': 'Open', 'P': 'In Progress', 'R': 'Resolved' };

        const detailHtml = `
            <div class="detail-row"><strong>ID:</strong> #${c.Complaint_id}</div>
            <div class="detail-row"><strong>Against:</strong> ${c.target_type} - ${escapeHtml(c.target_name)}</div>
            <div class="detail-row"><strong>Complainant:</strong> ${escapeHtml(c.complainant_name)}${c.complainant_phone ? ' (' + escapeHtml(c.complainant_phone) + ')' : ''}</div>
            <div class="detail-row"><strong>Status:</strong>
                <span class="status-badge status-${c.Status.toLowerCase()}">
                    ${statusMap[c.Status] || c.Status}
                </span>
            </div>
            <div class="detail-row"><strong>Created At:</strong> ${c.created_at}</div>
        `;

        document.getElementById('modal-detail').innerHTML = detailHtml;
        document.getElementById('modal-description').textContent = c.Description || '';

        // show previous reply if exists
        const replyContainer = document.getElementById('replyContainer');
        const replyBox       = document.getElementById('modal-reply');

        if (c.reply && c.reply.trim() !== '') {
            replyContainer.style.display = 'block';
            replyBox.textContent = c.reply;
        } else {
            replyContainer.style.display = 'none';
            replyBox.textContent = '';
        }

        // Fill form fields
        document.getElementById('modalComplaintId').value = c.Complaint_id;
        const statusSelect = document.getElementById('modalStatusSelect');
        if (statusSelect) {
            statusSelect.value = c.Status || 'O';
        }
        document.getElementById('replyText').value = '';

        document.getElementById('complaintModal').classList.add('show');
    }

    function closeModal() {
        document.getElementById('complaintModal').classList.remove('show');
    }

    window.onclick = function (event) {
        const modal = document.getElementById('complaintModal');
        if (event.target === modal) {
            closeModal();
        }
    };

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;");
    }
</script>
<script>
    // Auto hide alerts after 5 seconds
    setTimeout(() => {
        const alertBox = document.querySelector('.alert');
        if (alertBox) {
            alertBox.style.transition = "opacity 0.8s ease";
            alertBox.style.opacity = "0";

            // Fully remove after fade-out
            setTimeout(() => alertBox.remove(), 800);
        }
    }, 5000);
</script>

</body>
</html>

<?php require 'ofooter.php'; ?>
