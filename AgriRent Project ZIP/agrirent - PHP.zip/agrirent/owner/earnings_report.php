<?php
session_start();
require_once('../auth/config.php');

// -------- AUTH CHECK --------
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'O') {
    header("Location: ../login.php");
    exit();
}

$owner_id   = (int)$_SESSION['user_id'];
$owner_name = $_SESSION['user_name'] ?? 'Equipment Owner';

// -------- DATE FILTERS (LIKE ADMIN REPORT) --------
$today = new DateTime();

$date_from = $_GET['date_from'] ?? $today->format('Y-m-01');
$date_to   = $_GET['date_to']   ?? $today->format('Y-m-t');

// Basic validation: ensure valid date format; else reset to current month
$df_obj = DateTime::createFromFormat('Y-m-d', $date_from);
$dt_obj = DateTime::createFromFormat('Y-m-d', $date_to);

if (!$df_obj) {
    $date_from = $today->format('Y-m-01');
}
if (!$dt_obj) {
    $date_to = $today->format('Y-m-t');
}

// Ensure from <= to
if (strtotime($date_from) > strtotime($date_to)) {
    $tmp       = $date_from;
    $date_from = $date_to;
    $date_to   = $tmp;
}

/*
    STATUS (as per your note)
    -------------------------
    equipment_bookings.status : PEN, CON, COM, REJ
    product_orders.Status     : PEN, CON, COM, CAN

    ✅ For earnings and final counts we use ONLY:
       status = 'COM'  (COM = completed)
*/

// -------- AGGREGATE EARNINGS (FILTERED BY DATE RANGE) --------

// Equipment rental earnings for this owner (COMPLETED only)
$eq_query = "
    SELECT 
        COALESCE(SUM(CASE WHEN eb.status = 'COM' THEN eb.total_amount END), 0) AS equipment_earnings,
        COUNT(DISTINCT CASE WHEN eb.status = 'COM' THEN eb.booking_id END)     AS completed_bookings
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    WHERE e.Owner_id = ?
      AND eb.start_date BETWEEN ? AND ?
";
$eq_stmt = $conn->prepare($eq_query);
$eq_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$eq_stmt->execute();
$eq_stats = $eq_stmt->get_result()->fetch_assoc();
$eq_stmt->close();

// Product sales earnings for this owner as seller (COMPLETED only)
$prod_query = "
    SELECT 
        COALESCE(SUM(CASE WHEN po.Status = 'COM' THEN po.total_price END), 0) AS product_earnings,
        COUNT(DISTINCT CASE WHEN po.Status = 'COM' THEN po.Order_id END)      AS completed_orders
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    WHERE p.seller_id = ?
      AND po.order_date BETWEEN ? AND ?
";
$prod_stmt = $conn->prepare($prod_query);
$prod_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$prod_stmt->execute();
$prod_stats = $prod_stmt->get_result()->fetch_assoc();
$prod_stmt->close();

$eq_earnings    = (float)($eq_stats['equipment_earnings'] ?? 0);
$prod_earnings  = (float)($prod_stats['product_earnings'] ?? 0);
$total_earnings = $eq_earnings + $prod_earnings;

$eq_count   = (int)($eq_stats['completed_bookings'] ?? 0);
$prod_count = (int)($prod_stats['completed_orders'] ?? 0);

// -------- NEW: AGGREGATE SPEND (OWNER AS CUSTOMER/BUYER) --------

// Owner renting others' equipment (COM only, NOT his own equipment)
$spend_rent_query = "
    SELECT 
        COALESCE(SUM(eb.total_amount), 0) AS spent_rentals,
        COUNT(DISTINCT eb.booking_id)      AS spent_rental_count
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    WHERE eb.customer_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
      AND e.Owner_id <> ?
";
$spend_rent_stmt = $conn->prepare($spend_rent_query);
$spend_rent_stmt->bind_param("issi", $owner_id, $date_from, $date_to, $owner_id);
$spend_rent_stmt->execute();
$spend_rent_stats = $spend_rent_stmt->get_result()->fetch_assoc();
$spend_rent_stmt->close();

$spent_rentals       = (float)($spend_rent_stats['spent_rentals'] ?? 0);
$spent_rental_count  = (int)($spend_rent_stats['spent_rental_count'] ?? 0);

// Owner buying others' products (COM only, NOT his own products)
$spend_buy_query = "
    SELECT 
        COALESCE(SUM(po.total_price), 0) AS spent_purchases,
        COUNT(DISTINCT po.Order_id)      AS spent_order_count
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    WHERE po.buyer_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
      AND p.seller_id <> ?
";
$spend_buy_stmt = $conn->prepare($spend_buy_query);
$spend_buy_stmt->bind_param("issi", $owner_id, $date_from, $date_to, $owner_id);
$spend_buy_stmt->execute();
$spend_buy_stats = $spend_buy_stmt->get_result()->fetch_assoc();
$spend_buy_stmt->close();

$spent_purchases      = (float)($spend_buy_stats['spent_purchases'] ?? 0);
$spent_purchase_count = (int)($spend_buy_stats['spent_order_count'] ?? 0);

// Totals for this owner considering both roles
$total_spent     = $spent_rentals + $spent_purchases;
$net_position    = $total_earnings - $total_spent;  // what he keeps after his own spending
$total_spent_txn = $spent_rental_count + $spent_purchase_count;

// -------- DETAILED DATA (FILTERED BY DATE RANGE + COM) --------

// Earnings side: equipment bookings details (owner as owner, COM only)
$eq_detail_query = "
    SELECT 
        eb.booking_id, eb.start_date, eb.end_date, eb.Hours, eb.total_amount, eb.status,
        e.Title AS equipment_title, e.Brand, e.Model,
        u.Name AS customer_name
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    JOIN users u ON eb.customer_id = u.user_id
    WHERE e.Owner_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
    ORDER BY eb.booking_id DESC
";
$eq_detail_stmt = $conn->prepare($eq_detail_query);
$eq_detail_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$eq_detail_stmt->execute();
$eq_bookings = $eq_detail_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$eq_detail_stmt->close();

// Earnings side: product orders details (owner as seller, COM only)
$prod_detail_query = "
    SELECT 
        po.Order_id, po.quantity, po.total_price, po.order_date, po.Status,
        p.Name AS product_name,
        u.Name AS buyer_name,
        u.Phone AS buyer_phone
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    JOIN users u ON po.buyer_id = u.user_id
    WHERE p.seller_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    ORDER BY po.order_date DESC
";
$prod_detail_stmt = $conn->prepare($prod_detail_query);
$prod_detail_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$prod_detail_stmt->execute();
$prod_orders = $prod_detail_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$prod_detail_stmt->close();

// NEW: Spend side: equipment rentals as customer (COM, others' equipment)
$eq_spent_detail_query = "
    SELECT 
        eb.booking_id, eb.start_date, eb.end_date, eb.Hours, eb.total_amount,
        e.Title AS equipment_title, e.Brand, e.Model,
        u.Name AS owner_name
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    JOIN users u ON e.Owner_id = u.user_id
    WHERE eb.customer_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
      AND e.Owner_id <> ?
    ORDER BY eb.booking_id DESC
";
$eq_spent_detail_stmt = $conn->prepare($eq_spent_detail_query);
$eq_spent_detail_stmt->bind_param("issi", $owner_id, $date_from, $date_to, $owner_id);
$eq_spent_detail_stmt->execute();
$eq_spent_rows = $eq_spent_detail_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$eq_spent_detail_stmt->close();

// NEW: Spend side: product purchases as buyer (COM, others' products)
$prod_spent_detail_query = "
    SELECT 
        po.Order_id, po.quantity, po.total_price, po.order_date,
        p.Name AS product_name,
        u.Name AS seller_name,
        u.Phone AS seller_phone
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    JOIN users u ON p.seller_id = u.user_id
    WHERE po.buyer_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
      AND p.seller_id <> ?
    ORDER BY po.order_date DESC
";
$prod_spent_detail_stmt = $conn->prepare($prod_spent_detail_query);
$prod_spent_detail_stmt->bind_param("issi", $owner_id, $date_from, $date_to, $owner_id);
$prod_spent_detail_stmt->execute();
$prod_spent_rows = $prod_spent_detail_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$prod_spent_detail_stmt->close();

// Recompute totals from detailed rows (for safety)
$eq_total_from_rows   = 0;
foreach ($eq_bookings as $b) {
    $eq_total_from_rows += (float)$b['total_amount'];
}
$prod_total_from_rows = 0;
foreach ($prod_orders as $o) {
    $prod_total_from_rows += (float)$o['total_price'];
}
if (abs($eq_total_from_rows - $eq_earnings) > 0.01) {
    $eq_earnings = $eq_total_from_rows;
}
if (abs($prod_total_from_rows - $prod_earnings) > 0.01) {
    $prod_earnings = $prod_total_from_rows;
}
$total_earnings = $eq_earnings + $prod_earnings;

// -------- MONTHLY EARNINGS TREND (PER MONTH FOR THIS OWNER, COM ONLY) --------

// Equipment monthly earnings (COM)
$eq_month_query = "
    SELECT DATE_FORMAT(eb.start_date, '%Y-%m') AS ym,
           COALESCE(SUM(eb.total_amount), 0)   AS amount
    FROM equipment_bookings eb
    JOIN equipment e ON eb.equipment_id = e.Equipment_id
    WHERE e.Owner_id = ?
      AND eb.status = 'COM'
      AND eb.start_date BETWEEN ? AND ?
    GROUP BY ym
    ORDER BY ym
";
$eq_month_stmt = $conn->prepare($eq_month_query);
$eq_month_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$eq_month_stmt->execute();
$eq_month_res = $eq_month_stmt->get_result();
$eqMonthly = [];
while ($row = $eq_month_res->fetch_assoc()) {
    $eqMonthly[$row['ym']] = (float)$row['amount'];
}
$eq_month_stmt->close();

// Product monthly earnings (COM)
$prod_month_query = "
    SELECT DATE_FORMAT(po.order_date, '%Y-%m') AS ym,
           COALESCE(SUM(po.total_price), 0)     AS amount
    FROM product_orders po
    JOIN product p ON po.Product_id = p.product_id
    WHERE p.seller_id = ?
      AND po.Status = 'COM'
      AND po.order_date BETWEEN ? AND ?
    GROUP BY ym
    ORDER BY ym
";
$prod_month_stmt = $conn->prepare($prod_month_query);
$prod_month_stmt->bind_param("iss", $owner_id, $date_from, $date_to);
$prod_month_stmt->execute();
$prod_month_res = $prod_month_stmt->get_result();
$prodMonthly = [];
while ($row = $prod_month_res->fetch_assoc()) {
    $prodMonthly[$row['ym']] = (float)$row['amount'];
}
$prod_month_stmt->close();

// Merge months and build aligned arrays
$months_keys = array_unique(array_merge(array_keys($eqMonthly), array_keys($prodMonthly)));
sort($months_keys); // ascending year-month

$monthLabels   = [];
$eqMonthData   = [];
$prodMonthData = [];

foreach ($months_keys as $ym) {
    $monthLabels[]   = date('M Y', strtotime($ym . '-01'));
    $eqMonthData[]   = $eqMonthly[$ym]   ?? 0;
    $prodMonthData[] = $prodMonthly[$ym] ?? 0;
}

// -------- EXPORT (PDF / EXCEL) IN SAME PAGE (INCLUDES SPEND LOGIC) --------
if (isset($_POST['export_format'])) {
    $format = $_POST['export_format'];

    ob_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>AgriRent - Owner Earnings & Spend Report</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                font-size: 12px;
                color: #333;
                margin: 20px;
                position: relative;
            }
            .export-header {
                display: flex;
                align-items: center;
                border-bottom: 2px solid #234a23;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            .export-header img {
                height: 60px;
                width: 60px;
                border-radius: 50%;
                background: #fff;
                padding: 4px;
                object-fit: cover;
                box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                margin-right: 15px;
            }
            .export-header h1 {
                margin: 0;
                font-size: 20px;
                color: #234a23;
            }
            .export-header p {
                margin: 2px 0 0 0;
                font-size: 11px;
                color: #666;
            }
            h2 {
                margin-top: 25px;
                color: #234a23;
                font-size: 15px;
                border-bottom: 1px solid #e0e0e0;
                padding-bottom: 5px;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
                margin-bottom: 15px;
            }
            th, td {
                border: 1px solid #999;
                padding: 6px 5px;
                text-align: left;
                font-size: 11px;
            }
            th {
                background: #e8f5e9;
                color: #234a23;
                font-weight: bold;
            }
            .amount-cell {
                text-align: right;
                font-weight: bold;
            }
            .summary-table th {
                width: 45%;
            }
            .watermark {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-30deg);
                font-size: 60px;
                color: rgba(35, 74, 35, 0.06);
                z-index: -1;
                pointer-events: none;
                white-space: nowrap;
            }
            .footer {
                margin-top: 20px;
                font-size: 10px;
                text-align: center;
                color: #777;
                border-top: 1px solid #e0e0e0;
                padding-top: 6px;
            }
            @media print {
                .watermark { z-index: 0; }
            }
        </style>
    </head>
    <body>
        <div class="watermark">AgriRent</div>

        <div class="export-header">
            <img src="../Logo.png" alt="AgriRent Logo">
            <div>
                <h1>AgriRent - Owner Earnings & Spend Report</h1>
                <p>
                    Owner: <strong><?= htmlspecialchars($owner_name) ?></strong><br>
                    Period: <?= htmlspecialchars($date_from) ?> to <?= htmlspecialchars($date_to) ?><br>
                    Generated on: <?= date('d-m-Y H:i:s') ?>
                </p>
            </div>
        </div>

        <h2>Summary (Earnings & Spend)</h2>
        <table class="summary-table">
            <tr>
                <th>Equipment Rental Earnings</th>
                <td class="amount-cell">₹<?= number_format($eq_earnings, 2) ?></td>
            </tr>
            <tr>
                <th>Product Sales Earnings</th>
                <td class="amount-cell">₹<?= number_format($prod_earnings, 2) ?></td>
            </tr>
            <tr>
                <th>Total Earnings</th>
                <td class="amount-cell">₹<?= number_format($total_earnings, 2) ?></td>
            </tr>
            <tr>
                <th>Spent on Equipment Rentals (Others)</th>
                <td class="amount-cell">₹<?= number_format($spent_rentals, 2) ?></td>
            </tr>
            <tr>
                <th>Spent on Product Purchases (Others)</th>
                <td class="amount-cell">₹<?= number_format($spent_purchases, 2) ?></td>
            </tr>
            <tr>
                <th>Total Money Spent (Rent + Buy from Others)</th>
                <td class="amount-cell">₹<?= number_format($total_spent, 2) ?></td>
            </tr>
            <tr>
                <th>Net Position (Earnings - Spend)</th>
                <td class="amount-cell">₹<?= number_format($net_position, 2) ?></td>
            </tr>
        </table>

        <h2>Equipment Rental Earnings (Bookings)</h2>
        <table>
            <tr>
                <th>Booking ID</th>
                <th>Equipment</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Customer</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Hours</th>
                <th>Amount (₹)</th>
            </tr>
            <?php if (!empty($eq_bookings)): ?>
                <?php foreach ($eq_bookings as $b): ?>
                    <tr>
                        <td><?= (int)$b['booking_id'] ?></td>
                        <td><?= htmlspecialchars($b['equipment_title']) ?></td>
                        <td><?= htmlspecialchars($b['Brand'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($b['Model'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($b['customer_name']) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['start_date'])) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['end_date'])) ?></td>
                        <td><?= (int)$b['Hours'] ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$b['total_amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="8" style="text-align:right;">TOTAL EQUIPMENT EARNINGS</th>
                    <th class="amount-cell">₹<?= number_format($eq_earnings, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="9" style="text-align:center;">No completed equipment bookings in this period</td></tr>
            <?php endif; ?>
        </table>

        <h2>Product Sales Earnings (Orders)</h2>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Buyer</th>
                <th>Buyer Phone</th>
                <th>Quantity</th>
                <th>Order Date</th>
                <th>Amount (₹)</th>
            </tr>
            <?php if (!empty($prod_orders)): ?>
                <?php foreach ($prod_orders as $o): ?>
                    <tr>
                        <td><?= (int)$o['Order_id'] ?></td>
                        <td><?= htmlspecialchars($o['product_name']) ?></td>
                        <td><?= htmlspecialchars($o['buyer_name']) ?></td>
                        <td><?= htmlspecialchars($o['buyer_phone']) ?></td>
                        <td><?= number_format((float)$o['quantity'], 2) ?></td>
                        <td><?= date('Y-m-d', strtotime($o['order_date'])) ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$o['total_price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="6" style="text-align:right;">TOTAL PRODUCT EARNINGS</th>
                    <th class="amount-cell">₹<?= number_format($prod_earnings, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">No completed product sales in this period</td></tr>
            <?php endif; ?>
        </table>

        <h2>Equipment Rentals as Customer (Money Spent)</h2>
        <table>
            <tr>
                <th>Booking ID</th>
                <th>Equipment</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Owner</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Hours</th>
                <th>Amount (₹)</th>
            </tr>
            <?php if (!empty($eq_spent_rows)): ?>
                <?php foreach ($eq_spent_rows as $b): ?>
                    <tr>
                        <td><?= (int)$b['booking_id'] ?></td>
                        <td><?= htmlspecialchars($b['equipment_title']) ?></td>
                        <td><?= htmlspecialchars($b['Brand'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($b['Model'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($b['owner_name']) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['start_date'])) ?></td>
                        <td><?= date('Y-m-d', strtotime($b['end_date'])) ?></td>
                        <td><?= (int)$b['Hours'] ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$b['total_amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="8" style="text-align:right;">TOTAL SPENT ON RENTALS</th>
                    <th class="amount-cell">₹<?= number_format($spent_rentals, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="9" style="text-align:center;">No completed rentals from other owners in this period</td></tr>
            <?php endif; ?>
        </table>

        <h2>Product Purchases as Buyer (Money Spent)</h2>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Seller</th>
                <th>Seller Phone</th>
                <th>Quantity</th>
                <th>Order Date</th>
                <th>Amount (₹)</th>
            </tr>
            <?php if (!empty($prod_spent_rows)): ?>
                <?php foreach ($prod_spent_rows as $o): ?>
                    <tr>
                        <td><?= (int)$o['Order_id'] ?></td>
                        <td><?= htmlspecialchars($o['product_name']) ?></td>
                        <td><?= htmlspecialchars($o['seller_name']) ?></td>
                        <td><?= htmlspecialchars($o['seller_phone']) ?></td>
                        <td><?= number_format((float)$o['quantity'], 2) ?></td>
                        <td><?= date('Y-m-d', strtotime($o['order_date'])) ?></td>
                        <td class="amount-cell">₹<?= number_format((float)$o['total_price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <th colspan="6" style="text-align:right;">TOTAL SPENT ON PURCHASES</th>
                    <th class="amount-cell">₹<?= number_format($spent_purchases, 2) ?></th>
                </tr>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">No completed purchases from other sellers in this period</td></tr>
            <?php endif; ?>
        </table>

        <div class="footer">
            This report was generated by AgriRent Owner Dashboard. © <?= date('Y') ?> AgriRent. All rights reserved.
        </div>

        <?php if ($format === 'pdf'): ?>
        <script>
            window.onload = function() { window.print(); };
        </script>
        <?php endif; ?>
    </body>
    </html>
    <?php
    $html = ob_get_clean();

    if ($format === 'excel') {
        header("Content-Type: application/vnd.ms-excel; charset=utf-8");
        header("Content-Disposition: attachment; filename=Owner_Earnings_Report_".date('Ymd_His').".xls");
        echo $html;
        exit;
    }

    if ($format === 'pdf') {
        header("Content-Type: text/html; charset=utf-8");
        echo $html;
        exit;
    }
}

// -------- NORMAL PAGE RENDER --------
require 'oheader.php';
require 'owner_nav.php';
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    .main-content {
        margin-left: 250px;
        padding: 25px;
        background-color: #f8f9fa;
        min-height: 100vh;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        background: white;
        padding: 20px 25px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }

    .page-header h1 {
        color: #234a23;
        font-size: 26px;
        font-weight: 600;
        margin: 0;
    }

    .page-header p {
        margin: 5px 0 0 0;
        color: #666;
        font-size: 14px;
    }

    .export-buttons {
        display: flex;
        gap: 10px;
    }

    .btn {
        padding: 10px 18px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s ease;
        font-size: 14px;
    }

    .btn-primary {
        background: #234a23;
        color: white;
    }

    .btn-primary:hover {
        background: #1b371b;
        transform: translateY(-1px);
    }

    .btn-secondary {
        background: #28a745;
        color: white;
    }

    .btn-secondary:hover {
        background: #218838;
        transform: translateY(-1px);
    }

    .tabs {
        display: flex;
        gap: 1rem;
        margin: 15px 0 20px;
    }

    .tab {
        padding: 10px 20px;
        border-radius: 20px;
        background: #e9f2eb;
        color: #234a23;
        font-weight: 600;
        border: none;
        cursor: default;
    }

    .filter-card {
        background: white;
        padding: 18px 20px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }

    .filter-form {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: flex-end;
    }

    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .filter-group label {
        font-size: 13px;
        color: #555;
        font-weight: 600;
    }

    .form-input {
        padding: 8px 10px;
        border-radius: 6px;
        border: 1px solid #ced4da;
        font-size: 14px;
    }

    .metrics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
        gap: 20px;
        margin-bottom: 25px;
    }

    .metric-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }

    .metric-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }

    .metric-title {
        font-size: 14px;
        font-weight: 600;
        color: #6c757d;
    }

    .metric-total {
        font-size: 22px;
        font-weight: 700;
        color: #234a23;
    }

    .metric-sub {
        font-size: 13px;
        color: #777;
    }

    .metric-total.negative {
        color: #c62828;
    }

    .charts-section {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 20px;
        margin-bottom: 25px;
    }

    .chart-card {
        background: white;
        padding: 18px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }

    .chart-card h3 {
        margin: 0 0 10px 0;
        font-size: 15px;
        color: #234a23;
    }

    .table-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }

    .table-card h2 {
        margin: 0 0 15px 0;
        font-size: 16px;
        color: #234a23;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 10px 8px;
        text-align: left;
        border-bottom: 1px solid #e9ecef;
    }

    th {
        background: #f8f9fa;
        font-weight: 600;
        color: #495057;
    }

    tr:hover td {
        background: #f8fbfa;
    }

    .amount-cell {
        text-align: right;
        font-weight: 600;
        color: #234a23;
    }

    .total-row td {
        background: #234a23;
        color: white;
        font-weight: 700;
    }

    .no-data {
        text-align: center;
        padding: 25px 10px;
        color: #888;
        font-style: italic;
    }

    .summary-container {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        margin-top: 10px;
    }

    .summary-title {
        font-size: 16px;
        font-weight: 600;
        color: #234a23;
        margin-bottom: 15px;
    }

    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 15px;
    }

    .summary-card {
        background: #f8fbfa;
        border-radius: 8px;
        padding: 15px;
        border: 1px solid #e1e5ea;
    }

    .summary-card-label {
        font-size: 12px;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        margin-bottom: 6px;
    }

    .summary-card-value {
        font-size: 20px;
        font-weight: 700;
        color: #234a23;
    }

    .summary-card-value.negative {
        color: #c62828;
    }

    @media (max-width: 992px) {
        .main-content {
            margin-left: 0;
            padding: 15px;
        }
    }

    @media print {
        .main-content {
            margin-left: 0;
            padding: 0;
        }
        .export-buttons, .filter-card {
            display: none !important;
        }
    }
</style>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Owner Earnings & Spend Report</h1>
            <p>
                Owner: <strong><?php echo htmlspecialchars($owner_name); ?></strong><br>
                Period: <?php echo htmlspecialchars($date_from); ?> to <?php echo htmlspecialchars($date_to); ?><br>
                Generated: <?php echo date('l, F j, Y H:i:s'); ?>
            </p>
        </div>
        <div class="export-buttons">
            <form method="POST" style="display:inline;">
                <button type="submit" name="export_format" value="pdf" class="btn btn-primary">Export PDF</button>
                <button type="submit" name="export_format" value="excel" class="btn btn-secondary">Export Excel</button>
            </form>
        </div>
    </div>

    <div class="tabs">
        <button class="tab">Overview </button>
    </div>

    <!-- DATE FILTER (LIKE ADMIN) -->
    <div class="filter-card">
        <form method="GET" class="filter-form">
            <div class="filter-group">
                <label>From Date:</label>
                <input type="date" name="date_from" class="form-input"
                       value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            <div class="filter-group">
                <label>To Date:</label>
                <input type="date" name="date_to" class="form-input"
                       value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            <div class="filter-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary">Apply Filters</button>
            </div>
        </form>
    </div>

    <!-- Metrics -->
    <div class="metrics-grid">
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Equipment Earnings</span>
                <span class="metric-total">₹<?php echo number_format($eq_earnings, 2); ?></span>
            </div>
            <div class="metric-sub">Completed Bookings: <?php echo $eq_count; ?></div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Product Sales Earnings</span>
                <span class="metric-total">₹<?php echo number_format($prod_earnings, 2); ?></span>
            </div>
            <div class="metric-sub">Completed Orders: <?php echo $prod_count; ?></div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Total Earnings</span>
                <span class="metric-total">₹<?php echo number_format($total_earnings, 2); ?></span>
            </div>
            <div class="metric-sub">Equipment + Product</div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Money Spent</span>
                <span class="metric-total">₹<?php echo number_format($total_spent, 2); ?></span>
            </div>
            <div class="metric-sub">
                Rentals: ₹<?php echo number_format($spent_rentals, 0); ?> • Purchases: ₹<?php echo number_format($spent_purchases, 0); ?>
            </div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Net Position</span>
                <span class="metric-total <?php echo $net_position < 0 ? 'negative' : ''; ?>">
                    ₹<?php echo number_format($net_position, 2); ?>
                </span>
            </div>
            <div class="metric-sub">Earnings - Spend</div>
        </div>
        <div class="metric-card">
            <div class="metric-header">
                <span class="metric-title">Completed Transactions</span>
                <span class="metric-total">
                    <?php echo $eq_count + $prod_count + $total_spent_txn; ?>
                </span>
            </div>
            <div class="metric-sub">
                Earn: <?php echo $eq_count + $prod_count; ?> • Spend: <?php echo $total_spent_txn; ?>
            </div>
        </div>
    </div>

    <!-- Charts Section (Agriculture Colours, earnings-focused) -->
    <div class="charts-section">
        <div class="chart-card">
            <h3>Earnings Breakdown (₹)</h3>
            <canvas id="earningsBarChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>Equipment vs Product Share</h3>
            <canvas id="earningsPieChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>Completed Transactions Count (Earn)</h3>
            <canvas id="countBarChart"></canvas>
        </div>
        <div class="chart-card">
            <h3>Monthly Earnings Trend</h3>
            <canvas id="monthlyLineChart"></canvas>
        </div>
    </div>

    <!-- Earnings Tables -->
    <div class="table-card">
        <h2>Equipment Rental Earnings (Bookings)</h2>
        <?php if (!empty($eq_bookings)): ?>
            <table>
                <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Equipment</th>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Customer</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Hours</th>
                    <th>Amount (₹)</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($eq_bookings as $b): ?>
                    <tr>
                        <td><strong><?php echo (int)$b['booking_id']; ?></strong></td>
                        <td><?php echo htmlspecialchars($b['equipment_title']); ?></td>
                        <td><?php echo htmlspecialchars($b['Brand'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($b['Model'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($b['customer_name']); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($b['start_date'])); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($b['end_date'])); ?></td>
                        <td><?php echo (int)$b['Hours']; ?></td>
                        <td class="amount-cell">₹<?php echo number_format((float)$b['total_amount'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="8" style="text-align:right;">TOTAL EQUIPMENT EARNINGS</td>
                    <td class="amount-cell">₹<?php echo number_format($eq_earnings, 2); ?></td>
                </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed equipment bookings in this date range.</div>
        <?php endif; ?>
    </div>

    <div class="table-card">
        <h2>Product Sales Earnings (Orders)</h2>
        <?php if (!empty($prod_orders)): ?>
            <table>
                <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product</th>
                    <th>Buyer</th>
                    <th>Buyer Phone</th>
                    <th>Quantity</th>
                    <th>Order Date</th>
                    <th>Amount (₹)</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($prod_orders as $o): ?>
                    <tr>
                        <td><strong><?php echo (int)$o['Order_id']; ?></strong></td>
                        <td><?php echo htmlspecialchars($o['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($o['buyer_name']); ?></td>
                        <td><?php echo htmlspecialchars($o['buyer_phone']); ?></td>
                        <td><?php echo number_format((float)$o['quantity'], 2); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($o['order_date'])); ?></td>
                        <td class="amount-cell">₹<?php echo number_format((float)$o['total_price'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="6" style="text-align:right;">TOTAL PRODUCT EARNINGS</td>
                    <td class="amount-cell">₹<?php echo number_format($prod_earnings, 2); ?></td>
                </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed product sales in this date range.</div>
        <?php endif; ?>
    </div>

    <!-- NEW: Spend Tables -->
    <div class="table-card">
        <h2>Equipment Rentals as Customer (Money Spent)</h2>
        <?php if (!empty($eq_spent_rows)): ?>
            <table>
                <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Equipment</th>
                    <th>Brand</th>
                    <th>Model</th>
                    <th>Owner</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Hours</th>
                    <th>Amount (₹)</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($eq_spent_rows as $b): ?>
                    <tr>
                        <td><strong><?php echo (int)$b['booking_id']; ?></strong></td>
                        <td><?php echo htmlspecialchars($b['equipment_title']); ?></td>
                        <td><?php echo htmlspecialchars($b['Brand'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($b['Model'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($b['owner_name']); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($b['start_date'])); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($b['end_date'])); ?></td>
                        <td><?php echo (int)$b['Hours']; ?></td>
                        <td class="amount-cell">₹<?php echo number_format((float)$b['total_amount'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="8" style="text-align:right;">TOTAL SPENT ON RENTALS</td>
                    <td class="amount-cell">₹<?php echo number_format($spent_rentals, 2); ?></td>
                </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed rentals from other owners in this date range.</div>
        <?php endif; ?>
    </div>

    <div class="table-card">
        <h2>Product Purchases as Buyer (Money Spent)</h2>
        <?php if (!empty($prod_spent_rows)): ?>
            <table>
                <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product</th>
                    <th>Seller</th>
                    <th>Seller Phone</th>
                    <th>Quantity</th>
                    <th>Order Date</th>
                    <th>Amount (₹)</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($prod_spent_rows as $o): ?>
                    <tr>
                        <td><strong><?php echo (int)$o['Order_id']; ?></strong></td>
                        <td><?php echo htmlspecialchars($o['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($o['seller_name']); ?></td>
                        <td><?php echo htmlspecialchars($o['seller_phone']); ?></td>
                        <td><?php echo number_format((float)$o['quantity'], 2); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($o['order_date'])); ?></td>
                        <td class="amount-cell">₹<?php echo number_format((float)$o['total_price'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="6" style="text-align:right;">TOTAL SPENT ON PURCHASES</td>
                    <td class="amount-cell">₹<?php echo number_format($spent_purchases, 2); ?></td>
                </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">No completed purchases from other sellers in this date range.</div>
        <?php endif; ?>
    </div>

    <!-- Summary -->
    <div class="summary-container">
        <div class="summary-title">Overall Summary</div>
        <div class="summary-grid">
            <div class="summary-card">
                <div class="summary-card-label">Total Earnings</div>
                <div class="summary-card-value">
                    ₹<?php echo number_format($total_earnings, 2); ?>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-label">Total Money Spent</div>
                <div class="summary-card-value">
                    ₹<?php echo number_format($total_spent, 2); ?>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-card-label">Net Position</div>
                <div class="summary-card-value <?php echo $net_position < 0 ? 'negative' : ''; ?>">
                    ₹<?php echo number_format($net_position, 2); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Agriculture colour palette
    const agrColors = {
        green:      '#2e7d32',
        lightGreen: '#66bb6a',
        yellow:     '#fbc02d',
        brown:      '#8d6e63',
        darkgreen:  '#234a23',
        red:        '#e53935',
        grey:       '#cfd8dc'
    };

    const eqEarnings    = <?php echo json_encode($eq_earnings); ?>;
    const prodEarnings  = <?php echo json_encode($prod_earnings); ?>;
    const totalEarnings = <?php echo json_encode($total_earnings); ?>;
    const eqCount       = <?php echo json_encode($eq_count); ?>;
    const prodCount     = <?php echo json_encode($prod_count); ?>;

    const monthLabels   = <?php echo json_encode($monthLabels); ?>;
    const eqMonthData   = <?php echo json_encode($eqMonthData); ?>;
    const prodMonthData = <?php echo json_encode($prodMonthData); ?>;

    // Earnings Bar Chart
    const barCtx = document.getElementById('earningsBarChart');
    if (barCtx) {
        new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: ['Equipment', 'Products', 'Total'],
                datasets: [{
                    label: 'Earnings (₹)',
                    data: [eqEarnings, prodEarnings, totalEarnings],
                    backgroundColor: [agrColors.brown, agrColors.green, agrColors.yellow],
                    borderColor: [agrColors.brown, agrColors.green, agrColors.yellow],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Earnings Pie Chart
    const pieCtx = document.getElementById('earningsPieChart');
    if (pieCtx) {
        new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: ['Equipment', 'Products'],
                datasets: [{
                    data: [eqEarnings, prodEarnings],
                    backgroundColor: [agrColors.darkgreen, agrColors.yellow],
                    borderColor: '#ffffff',
                    borderWidth: 2
                }]
            },
            options: {
                plugins: { legend: { position: 'bottom' } },
                responsive: true
            }
        });
    }

    // Transactions Count Chart (earn side only)
    const countCtx = document.getElementById('countBarChart');
    if (countCtx) {
        new Chart(countCtx, {
            type: 'bar',
            data: {
                labels: ['Equipment Bookings ', 'Product Orders '],
                datasets: [{
                    label: 'Completed Transactions',
                    data: [eqCount, prodCount],
                    backgroundColor: [agrColors.lightGreen, agrColors.green],
                    borderColor: [agrColors.lightGreen, agrColors.green],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                responsive: true,
                scales: { y: { beginAtZero: true, precision: 0 } }
            }
        });
    }

    // Monthly Earnings Trend Chart
    const monthlyCtx = document.getElementById('monthlyLineChart');
    if (monthlyCtx) {
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: monthLabels,
                datasets: [
                    {
                        label: 'Equipment Earnings (₹)',
                        data: eqMonthData,
                        borderColor: agrColors.green,
                        backgroundColor: 'rgba(46, 125, 50, 0.15)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Product Earnings (₹)',
                        data: prodMonthData,
                        borderColor: agrColors.yellow,
                        backgroundColor: 'rgba(251, 192, 45, 0.15)',
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                plugins: {
                    legend: { position: 'bottom' }
                },
                responsive: true,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }
</script>

<?php require 'ofooter.php'; ?>
